package com.aiagent.phone;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Всё, что ИИ умеет делать на телефоне. */
public class Tools implements Agent.ToolRunner {

    public static final int REQ_CONTACTS = 501;

    private final Activity act;

    public Tools(Activity act) {
        this.act = act;
    }

    // ================================================================ описания для ИИ
    private static final String[][] NONE = {};

    /** params: {имя, тип, описание} или {имя, тип, описание, "opt"} для необязательного. */
    private static JSONObject def(String name, String desc, String[][] params) throws JSONException {
        JSONObject props = new JSONObject();
        JSONArray req = new JSONArray();
        for (String[] p : params) {
            props.put(p[0], new JSONObject().put("type", p[1]).put("description", p[2]));
            if (p.length < 4) req.put(p[0]);
        }
        return new JSONObject().put("name", name).put("description", desc)
                .put("parameters", new JSONObject().put("type", "object").put("properties", props).put("required", req));
    }

    public static JSONArray definitions() {
        try {
            JSONArray a = new JSONArray();
            a.put(def("open_app", "Открыть установленное приложение по названию (калькулятор, камера, телеграм, ютуб, настройки, галерея и т.д.).",
                    new String[][]{{"name", "string", "Название приложения, как его называет пользователь"}}));
            a.put(def("list_apps", "Список всех установленных приложений (названия).", NONE));
            a.put(def("open_url", "Открыть сайт в браузере.", new String[][]{{"url", "string", "Адрес сайта"}}));
            a.put(def("web_search", "Поиск в интернете (Google) — открывает результаты в браузере.",
                    new String[][]{{"query", "string", "Поисковый запрос"}}));
            a.put(def("youtube_search", "Найти видео или музыку на YouTube.",
                    new String[][]{{"query", "string", "Что искать"}}));
            a.put(def("set_alarm", "Поставить будильник.", new String[][]{
                    {"hour", "integer", "Час 0-23"}, {"minute", "integer", "Минуты 0-59"},
                    {"label", "string", "Подпись будильника", "opt"}}));
            a.put(def("set_timer", "Запустить таймер.", new String[][]{
                    {"seconds", "integer", "Длительность в секундах"}, {"label", "string", "Подпись", "opt"}}));
            a.put(def("find_contact", "Найти контакт в телефонной книге по имени и получить номер.",
                    new String[][]{{"name", "string", "Имя или часть имени, например Мама"}}));
            a.put(def("dial", "Открыть звонилку с номером (пользователь сам нажмёт вызов).",
                    new String[][]{{"number", "string", "Номер телефона"}}));
            a.put(def("send_sms", "Открыть SMS с готовым текстом (пользователь сам нажмёт отправить).", new String[][]{
                    {"number", "string", "Номер телефона"}, {"text", "string", "Текст сообщения"}}));
            a.put(def("send_email", "Открыть письмо с готовым текстом в почтовом приложении.", new String[][]{
                    {"to", "string", "Адрес получателя", "opt"}, {"subject", "string", "Тема"},
                    {"body", "string", "Текст письма"}}));
            a.put(def("navigate", "Открыть карту / маршрут до места.",
                    new String[][]{{"destination", "string", "Адрес или название места"}}));
            a.put(def("open_settings", "Открыть раздел настроек телефона.", new String[][]{
                    {"section", "string", "Один из: wifi, bluetooth, display, sound, battery, location, apps, mobile, airplane, nfc, date, language, security, storage, accessibility, developer, notifications, main"}}));
            a.put(def("flashlight", "Включить или выключить фонарик.",
                    new String[][]{{"on", "boolean", "true — включить, false — выключить"}}));
            a.put(def("set_volume", "Установить громкость.", new String[][]{
                    {"level", "integer", "Громкость 0-100 (процентов)"},
                    {"stream", "string", "music (по умолчанию), ring, alarm, notification", "opt"}}));
            a.put(def("media_control", "Управление музыкой/видео, которое сейчас играет.",
                    new String[][]{{"action", "string", "play_pause, play, pause, next, previous"}}));
            a.put(def("add_calendar_event", "Добавить событие / напоминание в календарь.", new String[][]{
                    {"title", "string", "Название"}, {"start", "string", "Начало в формате YYYY-MM-DD HH:MM"},
                    {"duration_minutes", "integer", "Длительность в минутах (по умолчанию 60)", "opt"}}));
            a.put(def("copy_text", "Скопировать текст в буфер обмена.", new String[][]{{"text", "string", "Текст"}}));
            a.put(def("share_text", "Поделиться текстом (откроется выбор приложения).", new String[][]{{"text", "string", "Текст"}}));
            a.put(def("device_info", "Информация о телефоне: заряд батареи, модель, версия Android, свободная память.", NONE));
            a.put(def("get_time", "Текущие дата и время.", NONE));
            a.put(def("wait", "Подождать N секунд.", new String[][]{{"seconds", "number", "Секунды (до 15)"}}));
            return a;
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    // ================================================================ выполнение
    @Override
    public String execute(String name, JSONObject a) {
        try {
            switch (name) {
                case "open_app": return openApp(a.getString("name"));
                case "list_apps": return listApps();
                case "open_url": return openUrl(a.getString("url"));
                case "web_search":
                    return view("https://www.google.com/search?q=" + Uri.encode(a.getString("query")), "Открыт поиск");
                case "youtube_search":
                    return view("https://www.youtube.com/results?search_query=" + Uri.encode(a.getString("query")), "Открыт YouTube");
                case "set_alarm": return setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", ""));
                case "set_timer": return setTimer(a.getInt("seconds"), a.optString("label", ""));
                case "find_contact": return findContact(a.getString("name"));
                case "dial": return launchMsg(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.getString("number")))), "Открыта звонилка");
                case "send_sms": return sendSms(a.getString("number"), a.getString("text"));
                case "send_email": return sendEmail(a.optString("to", ""), a.optString("subject", ""), a.optString("body", ""));
                case "navigate":
                    return launchMsg(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.getString("destination")))), "Открыта карта");
                case "open_settings": return openSettings(a.getString("section"));
                case "flashlight": return flashlight(a.getBoolean("on"));
                case "set_volume": return setVolume(a.getInt("level"), a.optString("stream", "music"));
                case "media_control": return media(a.getString("action"));
                case "add_calendar_event": return calendar(a.getString("title"), a.getString("start"), a.optInt("duration_minutes", 60));
                case "copy_text": return copy(a.getString("text"));
                case "share_text": return share(a.getString("text"));
                case "device_info": return deviceInfo();
                case "get_time":
                    return new SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm:ss", new Locale("ru")).format(new Date());
                case "wait":
                    Thread.sleep((long) (Math.max(0, Math.min(a.getDouble("seconds"), 15)) * 1000));
                    return "Готово";
                default:
                    return "Ошибка: нет инструмента " + name;
            }
        } catch (JSONException e) {
            return "Ошибка аргументов: " + e.getMessage();
        } catch (SecurityException e) {
            return "Нет разрешения: " + e.getMessage();
        } catch (Exception e) {
            return "Ошибка: " + e;
        }
    }

    // ---------------------------------------------------------------- запуск активити
    /** Запуск на UI-потоке; возвращает null если успешно, иначе текст ошибки. */
    private String launch(final Intent intent) {
        if (!MainActivity.isResumed) {
            return "Не могу открыть: помощник свёрнут, а Android запрещает запуск приложений из фона. Попроси пользователя открыть помощника и повторить.";
        }
        final String[] err = {null};
        final CountDownLatch latch = new CountDownLatch(1);
        act.runOnUiThread(() -> {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                act.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                err[0] = "На телефоне нет приложения для этого действия.";
            } catch (Exception e) {
                err[0] = "Ошибка запуска: " + e;
            } finally {
                latch.countDown();
            }
        });
        try {
            latch.await(5, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return err[0];
    }

    private String launchMsg(Intent i, String okMsg) {
        String e = launch(i);
        return e != null ? e : okMsg;
    }

    private String view(String url, String okMsg) {
        return launchMsg(new Intent(Intent.ACTION_VIEW, Uri.parse(url)), okMsg + ": " + url);
    }

    private void onUi(final Runnable r) throws InterruptedException {
        final CountDownLatch latch = new CountDownLatch(1);
        act.runOnUiThread(() -> {
            try {
                r.run();
            } finally {
                latch.countDown();
            }
        });
        latch.await(5, TimeUnit.SECONDS);
    }

    // ---------------------------------------------------------------- приложения
    private static final Map<String, String[]> ALIASES = new HashMap<>();

    private static void al(String ru, String... keys) {
        ALIASES.put(ru, keys);
    }

    static {
        al("калькулятор", "calculator", "calc");
        al("камера", "camera");
        al("галерея", "gallery", "photos", "фото", "google фото");
        al("фото", "photos", "gallery", "галерея");
        al("настройки", "settings");
        al("часы", "clock", "будильник");
        al("будильник", "clock", "часы");
        al("телефон", "phone", "dialer", "звонки");
        al("звонилка", "phone", "dialer", "телефон");
        al("сообщения", "messages", "messaging", "sms", "смс");
        al("смс", "messages", "messaging", "сообщения");
        al("контакты", "contacts");
        al("браузер", "chrome", "browser", "яндекс", "firefox", "opera", "интернет");
        al("хром", "chrome");
        al("ютуб", "youtube");
        al("телеграм", "telegram");
        al("телеграмм", "telegram");
        al("тг", "telegram");
        al("ватсап", "whatsapp");
        al("вотсап", "whatsapp");
        al("вк", "vk", "vkontakte", "вконтакте");
        al("вконтакте", "vk", "vkontakte");
        al("инстаграм", "instagram");
        al("тикток", "tiktok", "musically");
        al("музыка", "music", "музыка");
        al("карты", "maps", "карты");
        al("навигатор", "navigator", "maps");
        al("почта", "gmail", "mail", "email", "почта");
        al("календарь", "calendar");
        al("плей маркет", "play store", "play маркет", "vending");
        al("плеймаркет", "play store", "play маркет", "vending");
        al("маркет", "play store", "play маркет", "vending", "rustore");
        al("заметки", "notes", "keep", "заметки");
        al("файлы", "files", "мои файлы", "file manager", "проводник");
        al("проводник", "files", "мои файлы", "file manager");
        al("погода", "weather");
        al("диктофон", "recorder", "voice recorder", "звукозапись");
        al("дискорд", "discord");
        al("спотифай", "spotify");
        al("стим", "steam");
        al("яндекс", "yandex");
        al("сбер", "sber", "сбербанк");
        al("сбербанк", "sber", "сбер");
        al("госуслуги", "gosuslugi");
        al("озон", "ozon");
        al("вайлдберриз", "wildberries");
        al("вб", "wildberries");
        al("авито", "avito");
        al("кинопоиск", "kinopoisk");
        al("ру стор", "rustore");
        al("рустор", "rustore");
        al("майнкрафт", "minecraft");
        al("стандофф", "standoff");
    }

    static String norm(String s) {
        return s.toLowerCase(Locale.ROOT).replace('ё', 'е').replaceAll("\\s+", " ").trim();
    }

    static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int c = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /** Ключи поиска: сам запрос + синонимы (в обе стороны). */
    static List<String> searchKeys(String query) {
        String q = norm(query);
        Set<String> keys = new LinkedHashSet<>();
        keys.add(q);
        if (q.startsWith("приложение ")) keys.add(q.substring(11));
        String[] direct = ALIASES.get(q);
        if (direct != null) Collections.addAll(keys, direct);
        for (Map.Entry<String, String[]> e : ALIASES.entrySet()) {
            for (String k : e.getValue()) {
                if (k.equals(q)) {
                    keys.add(e.getKey());
                    Collections.addAll(keys, e.getValue());
                }
            }
        }
        return new ArrayList<>(keys);
    }

    /** Оценка совпадения названия приложения с ключом (0 = не подходит). */
    static int score(String label, String pkg, String k) {
        if (k.isEmpty()) return 0;
        if (label.equals(k)) return 100;
        if (k.length() >= 2 && label.startsWith(k + " ")) return 85;
        if (k.length() >= 3 && label.startsWith(k)) return 80;
        if (k.length() >= 3 && label.contains(k)) return 60;
        String kk = k.replace(" ", "");
        if (kk.length() >= 3 && kk.matches("[a-z0-9.]+") && pkg.contains(kk)) return 50;
        if (k.length() >= 4) {
            int d = lev(label, k);
            if (d <= Math.max(1, k.length() / 3)) return 40 - d;
        }
        return 0;
    }

    private List<ResolveInfo> launchables() {
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        return act.getPackageManager().queryIntentActivities(main, 0);
    }

    private String openApp(String query) {
        PackageManager pm = act.getPackageManager();
        List<String> keys = searchKeys(query);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo ri : launchables()) {
            if (ri.activityInfo.packageName.equals(act.getPackageName())) continue;
            String label = norm(ri.loadLabel(pm).toString());
            String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
            for (int i = 0; i < keys.size(); i++) {
                int s = score(label, pkg, keys.get(i)) - (i == 0 ? 0 : 1); // точный запрос чуть важнее синонимов
                if (s > bestScore) {
                    bestScore = s;
                    best = ri;
                }
            }
        }
        if (best == null) {
            return "Не нашёл приложение «" + query + "». Установленные приложения: " + listApps();
        }
        Intent li = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(new ComponentName(best.activityInfo.packageName, best.activityInfo.name))
                .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        String err = launch(li);
        return err != null ? err : "Открыто приложение: " + best.loadLabel(pm);
    }

    private String listApps() {
        PackageManager pm = act.getPackageManager();
        TreeSet<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (ResolveInfo ri : launchables()) names.add(ri.loadLabel(pm).toString());
        return String.join(", ", names);
    }

    private String openUrl(String url) {
        url = url.trim();
        if (!url.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) url = "https://" + url;
        return view(url, "Открыто");
    }

    // ---------------------------------------------------------------- будильник, таймер
    private String setAlarm(int hour, int minute, String label) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        if (!label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
        return launchMsg(i, String.format(Locale.ROOT, "Будильник поставлен на %02d:%02d", hour, minute));
    }

    private String setTimer(int seconds, String label) {
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        if (!label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
        return launchMsg(i, "Таймер запущен на " + seconds + " сек.");
    }

    // ---------------------------------------------------------------- контакты, звонки, sms
    private String findContact(String name) throws InterruptedException {
        if (act.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            onUi(() -> act.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS));
            return "Нет доступа к контактам — пользователю показан запрос разрешения. Скажи ему разрешить и повторить команду.";
        }
        List<String> found = new ArrayList<>();
        String[] proj = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor c = act.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + name + "%"},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (c != null) while (c.moveToNext() && found.size() < 10) {
                String line = c.getString(0) + ": " + c.getString(1);
                if (!found.contains(line)) found.add(line);
            }
        }
        if (found.isEmpty()) return "Контакт «" + name + "» не найден. Попробуй другое написание (например уменьшительное имя).";
        return String.join("\n", found);
    }

    private String sendSms(String number, String text) {
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)));
        i.putExtra("sms_body", text);
        return launchMsg(i, "Открыто SMS с текстом — осталось нажать «Отправить»");
    }

    private String sendEmail(String to, String subject, String body) {
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        if (!to.isEmpty()) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
        i.putExtra(Intent.EXTRA_SUBJECT, subject);
        i.putExtra(Intent.EXTRA_TEXT, body);
        return launchMsg(i, "Открыто письмо — осталось нажать «Отправить»");
    }

    // ---------------------------------------------------------------- настройки
    private String openSettings(String section) {
        String s = norm(section);
        String action;
        switch (s) {
            case "wifi": case "wi-fi": case "вайфай": action = Settings.ACTION_WIFI_SETTINGS; break;
            case "bluetooth": case "блютуз": action = Settings.ACTION_BLUETOOTH_SETTINGS; break;
            case "display": case "экран": case "яркость": action = Settings.ACTION_DISPLAY_SETTINGS; break;
            case "sound": case "звук": action = Settings.ACTION_SOUND_SETTINGS; break;
            case "battery": case "батарея": action = Intent.ACTION_POWER_USAGE_SUMMARY; break;
            case "location": case "gps": case "геолокация": action = Settings.ACTION_LOCATION_SOURCE_SETTINGS; break;
            case "apps": case "приложения": action = Settings.ACTION_APPLICATION_SETTINGS; break;
            case "mobile": case "data": case "интернет": action = Settings.ACTION_DATA_ROAMING_SETTINGS; break;
            case "airplane": case "самолет": action = Settings.ACTION_AIRPLANE_MODE_SETTINGS; break;
            case "nfc": action = Settings.ACTION_NFC_SETTINGS; break;
            case "date": case "time": case "время": action = Settings.ACTION_DATE_SETTINGS; break;
            case "language": case "язык": action = Settings.ACTION_LOCALE_SETTINGS; break;
            case "security": case "безопасность": action = Settings.ACTION_SECURITY_SETTINGS; break;
            case "storage": case "память": action = Settings.ACTION_INTERNAL_STORAGE_SETTINGS; break;
            case "accessibility": action = Settings.ACTION_ACCESSIBILITY_SETTINGS; break;
            case "developer": action = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS; break;
            default: action = Settings.ACTION_SETTINGS; // в т.ч. уведомления — общего публичного экрана нет
        }
        String err = launch(new Intent(action));
        if (err != null && !action.equals(Settings.ACTION_SETTINGS)) {
            err = launch(new Intent(Settings.ACTION_SETTINGS));
            return err != null ? err : "Этот раздел не открылся, открыты общие настройки";
        }
        return err != null ? err : "Открыты настройки: " + section;
    }

    // ---------------------------------------------------------------- фонарик, громкость, медиа
    private String flashlight(boolean on) throws Exception {
        CameraManager cm = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            Boolean has = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (has != null && has) {
                cm.setTorchMode(id, on);
                return on ? "Фонарик включён" : "Фонарик выключен";
            }
        }
        return "На телефоне нет вспышки";
    }

    private String setVolume(int level, String stream) {
        AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
        int st;
        switch (norm(stream)) {
            case "ring": case "звонок": st = AudioManager.STREAM_RING; break;
            case "alarm": case "будильник": st = AudioManager.STREAM_ALARM; break;
            case "notification": case "уведомления": st = AudioManager.STREAM_NOTIFICATION; break;
            default: st = AudioManager.STREAM_MUSIC;
        }
        int max = am.getStreamMaxVolume(st);
        int v = Math.round(Math.max(0, Math.min(100, level)) * max / 100f);
        am.setStreamVolume(st, v, AudioManager.FLAG_SHOW_UI);
        return "Громкость (" + stream + ") установлена: " + level + "%";
    }

    private String media(String action) {
        int code;
        switch (norm(action)) {
            case "next": code = KeyEvent.KEYCODE_MEDIA_NEXT; break;
            case "previous": case "prev": code = KeyEvent.KEYCODE_MEDIA_PREVIOUS; break;
            case "play": code = KeyEvent.KEYCODE_MEDIA_PLAY; break;
            case "pause": case "stop": code = KeyEvent.KEYCODE_MEDIA_PAUSE; break;
            default: code = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
        }
        AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
        return "Отправлено: " + action;
    }

    // ---------------------------------------------------------------- календарь, текст
    private String calendar(String title, String start, int minutes) throws Exception {
        Date d = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).parse(start.trim());
        if (d == null) return "Не понял дату, нужен формат YYYY-MM-DD HH:MM";
        long begin = d.getTime();
        Intent i = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + minutes * 60000L);
        return launchMsg(i, "Открыт календарь с событием — осталось нажать «Сохранить»");
    }

    private String copy(final String text) throws InterruptedException {
        onUi(() -> {
            ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("text", text));
        });
        return "Скопировано в буфер обмена";
    }

    private String share(String text) {
        Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
        return launchMsg(Intent.createChooser(send, "Поделиться"), "Открыто меню «Поделиться»");
    }

    // ---------------------------------------------------------------- инфо
    String deviceInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Телефон: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL)
                .append(", Android ").append(Build.VERSION.RELEASE);
        try {
            BatteryManager bm = (BatteryManager) act.getSystemService(Context.BATTERY_SERVICE);
            int pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            Intent bi = act.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int status = bi == null ? -1 : bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
            sb.append("\nБатарея: ").append(pct).append("%").append(charging ? " (заряжается)" : "");
        } catch (Exception ignored) {
        }
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            sb.append("\nПамять: свободно ").append(fs.getAvailableBytes() / (1L << 30))
                    .append(" ГБ из ").append(fs.getTotalBytes() / (1L << 30)).append(" ГБ");
        } catch (Exception ignored) {
        }
        return sb.toString();
    }

    String shortDevice() {
        return Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE;
    }
}
