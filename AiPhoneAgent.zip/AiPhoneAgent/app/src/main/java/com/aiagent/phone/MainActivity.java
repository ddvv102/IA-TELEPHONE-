package com.aiagent.phone;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    static volatile boolean isResumed = false;
    private static final int REQ_SPEECH = 700;

    /** {название, тип API, адрес, модель по умолчанию} */
    static final String[][] PROVIDERS = {
            {"OpenAI", "openai", "https://api.openai.com/v1", "gpt-4o-mini"},
            {"Anthropic (Claude)", "anthropic", "https://api.anthropic.com", "claude-sonnet-5-5"},
            {"Google Gemini", "gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash"},
            {"DeepSeek", "openai", "https://api.deepseek.com/v1", "deepseek-chat"},
            {"Groq", "openai", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"},
            {"OpenRouter", "openai", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"},
            {"Mistral", "openai", "https://api.mistral.ai/v1", "mistral-large-latest"},
            {"Ollama (компьютер в сети)", "openai", "http://192.168.1.100:11434/v1", "qwen2.5:7b"},
            {"Свой (OpenAI-совместимый)", "openai", "https://example.com/v1", "model-name"},
    };

    private Spinner spProvider;
    private EditText etKey, etModel, etUrl, etInput;
    private CheckBox cbSpeak, cbAutoMic;
    private TextView tvChat;
    private ScrollView scroll, settingsPanel;
    private Button btnSend, btnMic;

    private SharedPreferences prefs;
    private Tools tools;
    private Agent agent;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private volatile boolean busy = false;
    private int currentProvider = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);

        spProvider = findViewById(R.id.spProvider);
        etKey = findViewById(R.id.etKey);
        etModel = findViewById(R.id.etModel);
        etUrl = findViewById(R.id.etUrl);
        etInput = findViewById(R.id.etInput);
        cbSpeak = findViewById(R.id.cbSpeak);
        cbAutoMic = findViewById(R.id.cbAutoMic);
        tvChat = findViewById(R.id.tvChat);
        scroll = findViewById(R.id.scroll);
        settingsPanel = findViewById(R.id.settingsPanel);
        btnSend = findViewById(R.id.btnSend);
        btnMic = findViewById(R.id.btnMic);

        tools = new Tools(this);
        agent = new Agent(tools, Tools.definitions(), (kind, text) -> runOnUiThread(() -> append(kind, text)));

        // список ИИ
        String[] names = new String[PROVIDERS.length];
        for (int i = 0; i < PROVIDERS.length; i++) names[i] = PROVIDERS[i][0];
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(0xFFFFFFFF);
                v.setTextSize(16);
                return v;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProvider.setAdapter(ad);
        currentProvider = Math.min(prefs.getInt("provider", 0), PROVIDERS.length - 1);
        spProvider.setSelection(currentProvider);
        loadProviderFields(currentProvider);
        spProvider.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == currentProvider) return;
                saveFields();
                currentProvider = position;
                prefs.edit().putInt("provider", position).apply();
                loadProviderFields(position);
                if (etKey.getText().toString().trim().isEmpty() && !isLocal()) settingsPanel.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        cbSpeak.setChecked(prefs.getBoolean("speak", false));
        cbAutoMic.setChecked(prefs.getBoolean("auto_mic", false));

        findViewById(R.id.btnSettings).setOnClickListener(v ->
                settingsPanel.setVisibility(settingsPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            saveFields();
            settingsPanel.setVisibility(View.GONE);
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnClear).setOnClickListener(v -> {
            if (busy) return;
            agent.reset();
            tvChat.setText("");
            hello();
        });
        btnSend.setOnClickListener(v -> {
            if (busy) {
                agent.cancelled = true;
                append("info", "Останавливаю…");
            } else send();
        });
        btnMic.setOnClickListener(v -> listen());
        etInput.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_SEND || enter) {
                send();
                return true;
            }
            return false;
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("ru", "RU"));
                ttsReady = true;
            }
        });

        hello();
        if (etKey.getText().toString().trim().isEmpty() && !isLocal()) settingsPanel.setVisibility(View.VISIBLE);
        else if (cbAutoMic.isChecked() && savedInstanceState == null) etInput.postDelayed(this::listen, 400);
    }

    private void hello() {
        append("info", "Привет! Выбери ИИ сверху, вставь API-ключ (⚙) и пиши или говори команды (🎤):\n"
                + "• открой калькулятор\n• поставь будильник на 7:30\n• включи фонарик\n"
                + "• позвони маме\n• найди на ютубе лофи музыку\n• сделай громкость 30%\n• как доехать до Красной площади");
    }

    // ------------------------------------------------------------ настройки ИИ
    private void loadProviderFields(int p) {
        String n = PROVIDERS[p][0];
        etKey.setText(prefs.getString("key_" + n, ""));
        etModel.setText(prefs.getString("model_" + n, PROVIDERS[p][3]));
        etUrl.setText(prefs.getString("url_" + n, PROVIDERS[p][2]));
    }

    private void saveFields() {
        String n = PROVIDERS[currentProvider][0];
        prefs.edit()
                .putString("key_" + n, etKey.getText().toString().trim())
                .putString("model_" + n, etModel.getText().toString().trim())
                .putString("url_" + n, etUrl.getText().toString().trim())
                .putBoolean("speak", cbSpeak.isChecked())
                .putBoolean("auto_mic", cbAutoMic.isChecked())
                .apply();
    }

    private boolean isLocal() {
        String u = etUrl.getText().toString();
        return u.startsWith("http://");
    }

    private Agent.Config currentConfig() {
        String[] p = PROVIDERS[currentProvider];
        String model = etModel.getText().toString().trim();
        String url = etUrl.getText().toString().trim();
        Agent.Config c = new Agent.Config(p[1], model.isEmpty() ? p[3] : model,
                etKey.getText().toString().trim(), url.isEmpty() ? p[2] : url);
        c.deviceInfo = tools.shortDevice();
        return c;
    }

    // ------------------------------------------------------------ отправка
    private void send() {
        final String text = etInput.getText().toString().trim();
        if (text.isEmpty() || busy) return;
        saveFields();
        final Agent.Config cfg = currentConfig();
        if (cfg.key.isEmpty() && !isLocal()) {
            settingsPanel.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Вставь API-ключ для " + PROVIDERS[currentProvider][0], Toast.LENGTH_LONG).show();
            return;
        }
        etInput.setText("");
        append("user", text);
        setBusy(true);
        new Thread(() -> {
            try {
                String answer = agent.run(text, cfg);
                if (answer != null && !answer.isEmpty()) runOnUiThread(() -> speak(answer));
            } catch (java.net.UnknownHostException e) {
                runOnUiThread(() -> append("error", "Нет интернета или неверный адрес API."));
            } catch (java.net.ConnectException e) {
                runOnUiThread(() -> append("error", "Не удалось подключиться к " + cfg.baseUrl));
            } catch (java.net.SocketTimeoutException e) {
                runOnUiThread(() -> append("error", "ИИ слишком долго отвечает (таймаут). Попробуй ещё раз."));
            } catch (Exception e) {
                final String msg = e.getMessage() != null ? e.getMessage() : e.toString();
                runOnUiThread(() -> append("error", msg));
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        }).start();
    }

    private void setBusy(boolean b) {
        busy = b;
        btnSend.setText(b ? "■" : "▶");
        btnMic.setEnabled(!b);
    }

    private void speak(String text) {
        if (cbSpeak.isChecked() && ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "answer");
    }

    // ------------------------------------------------------------ голос
    private void listen() {
        if (busy) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажи, что сделать");
        try {
            startActivityForResult(i, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "На телефоне нет распознавания речи (нужно приложение Google)", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> res = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (res != null && !res.isEmpty()) {
                etInput.setText(res.get(0));
                // onResume наступит после onActivityResult — отправляем чуть позже
                etInput.postDelayed(this::send, 150);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == Tools.REQ_CONTACTS) {
            boolean ok = grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            append("info", ok ? "Доступ к контактам разрешён — повтори команду." : "Без доступа к контактам звонить по имени не получится.");
        }
    }

    // ------------------------------------------------------------ чат
    private void append(String kind, String text) {
        String prefix;
        int color;
        switch (kind) {
            case "user": prefix = "Вы: "; color = 0xFF2F49B0; break;
            case "ai": prefix = "ИИ: "; color = 0xFF1E1E1E; break;
            case "tool": prefix = ""; color = 0xFF8A8F98; break;
            case "error": prefix = "Ошибка: "; color = 0xFFC92A2A; break;
            default: prefix = ""; color = 0xFF2B8A3E;
        }
        String full = prefix + text + (kind.equals("tool") ? "\n" : "\n\n");
        SpannableString s = new SpannableString(full);
        s.setSpan(new ForegroundColorSpan(color), 0, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (kind.equals("user")) s.setSpan(new StyleSpan(Typeface.BOLD), 0, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (kind.equals("tool")) {
            s.setSpan(new RelativeSizeSpan(0.82f), 0, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            s.setSpan(new TypefaceSpan("monospace"), 0, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        tvChat.append(s);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    // ------------------------------------------------------------ жизненный цикл
    @Override
    protected void onResume() {
        super.onResume();
        isResumed = true;
    }

    @Override
    protected void onPause() {
        isResumed = false;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
