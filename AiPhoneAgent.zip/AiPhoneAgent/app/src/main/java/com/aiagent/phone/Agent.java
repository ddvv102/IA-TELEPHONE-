package com.aiagent.phone;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Цикл "ИИ думает -> вызывает инструмент -> получает результат -> ..." для трёх форматов API:
 * OpenAI-совместимый (OpenAI, DeepSeek, Groq, OpenRouter, Mistral, Ollama...), Anthropic Claude, Google Gemini.
 */
public class Agent {

    public interface Logger {
        void log(String kind, String text);
    }

    /** Исполнитель инструментов (в приложении это Tools). */
    public interface ToolRunner {
        String execute(String name, JSONObject args);
    }

    public static class Config {
        public String type, model, key, baseUrl, deviceInfo = "";

        public Config(String type, String model, String key, String baseUrl) {
            this.type = type;
            this.model = model;
            this.key = key;
            this.baseUrl = baseUrl;
        }
    }

    static final int MAX_STEPS = 10;
    static final int MAX_HISTORY = 30;

    private final ToolRunner tools;
    private final JSONArray toolDefs;
    private final Logger log;
    private final List<JSONObject> history = new ArrayList<>();
    public volatile boolean cancelled = false;

    public Agent(ToolRunner tools, JSONArray toolDefs, Logger log) {
        this.tools = tools;
        this.toolDefs = toolDefs;
        this.log = log;
    }

    public synchronized void reset() {
        history.clear();
    }

    String systemPrompt(Config cfg) {
        String now = new SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", new Locale("ru")).format(new Date());
        return "Ты — ИИ-помощник, который управляет Android-телефоном пользователя с помощью инструментов.\n"
                + "Устройство: " + cfg.deviceInfo + ". Сейчас: " + now + ".\n"
                + "Правила:\n"
                + "- Выполняй просьбу сразу через инструменты, а не объясняй, как её сделать.\n"
                + "- Пользователь может писать с ошибками или голосом (\"конкулятор\" = калькулятор) — понимай смысл.\n"
                + "- Открыть приложение — open_app (передавай обычное название приложения, исправив опечатки). Если не найдено — посмотри list_apps и попробуй точное название.\n"
                + "- Позвонить или написать человеку по имени — сначала find_contact, потом dial / send_sms с номером.\n"
                + "- Будильник — set_alarm, таймер — set_timer, напоминание на дату — add_calendar_event.\n"
                + "- Найти в интернете — web_search; видео или музыку — youtube_search; сайт — open_url; маршрут — navigate.\n"
                + "- После открытия другого приложения помощник сворачивается и Android не даст открыть ещё что-то, поэтому открывай приложение/сайт последним действием и только одно.\n"
                + "- Если инструмент вернул ошибку — попробуй другой способ (до 2-3 попыток).\n"
                + "- Если пользователь просто задаёт вопрос — ответь сам, без инструментов.\n"
                + "- Когда задача выполнена, ответь кратко (1-2 предложения) на языке пользователя, без markdown.";
    }

    private void trim() {
        if (history.size() <= MAX_HISTORY) return;
        int start = history.size() - MAX_HISTORY;
        for (int i = start; i < history.size(); i++) {
            if ("user".equals(history.get(i).optString("role"))) {
                history.subList(0, i).clear();
                return;
            }
        }
    }

    /** Выполнить команду пользователя. Возвращает последний текстовый ответ ИИ. */
    public synchronized String run(String text, Config cfg) throws Exception {
        cancelled = false;
        history.add(new JSONObject().put("role", "user").put("text", text));
        trim();
        String lastText = "";
        try {
            for (int step = 0; step < MAX_STEPS; step++) {
                if (cancelled) {
                    log.log("info", "Остановлено.");
                    closeOpenTurn();
                    return lastText;
                }
                JSONObject resp;
                switch (cfg.type) {
                    case "anthropic":
                        resp = callAnthropic(cfg);
                        break;
                    case "gemini":
                        resp = callGemini(cfg);
                        break;
                    default:
                        resp = callOpenAI(cfg);
                }
                JSONObject msg = new JSONObject().put("role", "assistant")
                        .put("text", resp.optString("text", ""))
                        .put("calls", resp.getJSONArray("calls"));
                if (resp.has("raw")) msg.put("raw", resp.get("raw"));
                history.add(msg);

                String t = resp.optString("text", "").trim();
                if (!t.isEmpty()) {
                    lastText = t;
                    log.log("ai", t);
                }
                JSONArray calls = resp.getJSONArray("calls");
                if (calls.length() == 0) return lastText;

                JSONArray results = new JSONArray();
                for (int i = 0; i < calls.length(); i++) {
                    JSONObject c = calls.getJSONObject(i);
                    JSONObject args = c.optJSONObject("args");
                    if (args == null) args = new JSONObject();
                    log.log("tool", "⚙ " + c.getString("name") + " " + shortArgs(args));
                    String out = tools.execute(c.getString("name"), args);
                    out = cut(out, 4000);
                    log.log("tool", "   → " + cut(out, 300));
                    results.put(new JSONObject().put("id", c.getString("id"))
                            .put("name", c.getString("name")).put("content", out));
                }
                history.add(new JSONObject().put("role", "tool").put("results", results));
            }
            log.log("error", "Остановлено: больше " + MAX_STEPS + " шагов.");
            closeOpenTurn();
            return lastText;
        } catch (Exception e) {
            // чтобы история осталась корректной для следующего запроса
            if (!history.isEmpty()) {
                String role = history.get(history.size() - 1).optString("role");
                if ("user".equals(role)) history.remove(history.size() - 1);
                else closeOpenTurn();
            }
            throw e;
        }
    }

    private void closeOpenTurn() throws JSONException {
        if (!history.isEmpty() && "tool".equals(history.get(history.size() - 1).optString("role"))) {
            history.add(new JSONObject().put("role", "assistant").put("text", "(прервано)").put("calls", new JSONArray()));
        }
    }

    static String shortArgs(JSONObject a) {
        StringBuilder sb = new StringBuilder();
        java.util.Iterator<String> it = a.keys();
        while (it.hasNext()) {
            String k = it.next();
            if (sb.length() > 0) sb.append(", ");
            sb.append(k).append("=").append(cut(String.valueOf(a.opt(k)), 60));
        }
        return "(" + sb + ")";
    }

    static String cut(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…[обрезано]";
    }

    static String newId() {
        return "call_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16);
    }

    /** optString, который не превращает JSON null в строку "null". */
    static String str(JSONObject o, String key) {
        if (o == null || !o.has(key) || o.isNull(key)) return "";
        return o.optString(key, "");
    }

    static JSONObject parseArgs(String s) {
        if (s == null || s.trim().isEmpty()) return new JSONObject();
        try {
            return new JSONObject(s);
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    // ------------------------------------------------------------------ HTTP
    static JSONObject post(String url, JSONObject body, Map<String, String> headers) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            String resp = readAll(is);
            if (code < 200 || code >= 300) throw new Exception("API ответил " + code + ": " + cut(resp, 600));
            return new JSONObject(resp);
        } finally {
            c.disconnect();
        }
    }

    static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return bos.toString("UTF-8");
    }

    static String base(Config cfg) {
        String b = cfg.baseUrl.trim();
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        return b;
    }

    // ------------------------------------------------------------------ OpenAI-совместимые
    JSONObject callOpenAI(Config cfg) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", systemPrompt(cfg)));
        for (JSONObject m : history) {
            String role = m.getString("role");
            if (role.equals("user")) {
                msgs.put(new JSONObject().put("role", "user").put("content", m.getString("text")));
            } else if (role.equals("assistant")) {
                JSONObject d = new JSONObject().put("role", "assistant").put("content", m.optString("text", ""));
                JSONArray calls = m.optJSONArray("calls");
                if (calls != null && calls.length() > 0) {
                    JSONArray tc = new JSONArray();
                    for (int i = 0; i < calls.length(); i++) {
                        JSONObject c = calls.getJSONObject(i);
                        tc.put(new JSONObject().put("id", c.getString("id")).put("type", "function")
                                .put("function", new JSONObject().put("name", c.getString("name"))
                                        .put("arguments", c.getJSONObject("args").toString())));
                    }
                    d.put("tool_calls", tc);
                }
                msgs.put(d);
            } else if (role.equals("tool")) {
                JSONArray rs = m.getJSONArray("results");
                for (int i = 0; i < rs.length(); i++) {
                    JSONObject r = rs.getJSONObject(i);
                    msgs.put(new JSONObject().put("role", "tool").put("tool_call_id", r.getString("id"))
                            .put("content", r.getString("content")));
                }
            }
        }
        JSONArray tools = new JSONArray();
        for (int i = 0; i < toolDefs.length(); i++)
            tools.put(new JSONObject().put("type", "function").put("function", toolDefs.getJSONObject(i)));
        JSONObject body = new JSONObject().put("model", cfg.model).put("messages", msgs).put("tools", tools);

        Map<String, String> h = new LinkedHashMap<>();
        if (!cfg.key.isEmpty()) h.put("Authorization", "Bearer " + cfg.key);
        h.put("HTTP-Referer", "https://github.com/ai-phone-agent"); // для OpenRouter
        h.put("X-Title", "AI Phone Agent");
        JSONObject data = post(base(cfg) + "/chat/completions", body, h);

        JSONObject msg = data.getJSONArray("choices").getJSONObject(0).getJSONObject("message");
        JSONArray calls = new JSONArray();
        JSONArray tc = msg.optJSONArray("tool_calls");
        if (tc != null) {
            for (int i = 0; i < tc.length(); i++) {
                JSONObject c = tc.getJSONObject(i);
                JSONObject fn = c.getJSONObject("function");
                String id = str(c, "id");
                calls.put(new JSONObject().put("id", id.isEmpty() ? newId() : id)
                        .put("name", fn.getString("name"))
                        .put("args", parseArgs(str(fn, "arguments"))));
            }
        }
        return new JSONObject().put("text", str(msg, "content")).put("calls", calls);
    }

    // ------------------------------------------------------------------ Anthropic Claude
    JSONObject callAnthropic(Config cfg) throws Exception {
        JSONArray msgs = new JSONArray();
        for (JSONObject m : history) {
            String role = m.getString("role");
            if (role.equals("user")) {
                msgs.put(new JSONObject().put("role", "user").put("content", m.getString("text")));
            } else if (role.equals("assistant")) {
                JSONArray blocks = new JSONArray();
                String t = m.optString("text", "");
                if (!t.isEmpty()) blocks.put(new JSONObject().put("type", "text").put("text", t));
                JSONArray calls = m.optJSONArray("calls");
                if (calls != null) for (int i = 0; i < calls.length(); i++) {
                    JSONObject c = calls.getJSONObject(i);
                    blocks.put(new JSONObject().put("type", "tool_use").put("id", c.getString("id"))
                            .put("name", c.getString("name")).put("input", c.getJSONObject("args")));
                }
                if (blocks.length() == 0) blocks.put(new JSONObject().put("type", "text").put("text", "..."));
                msgs.put(new JSONObject().put("role", "assistant").put("content", blocks));
            } else if (role.equals("tool")) {
                JSONArray rs = m.getJSONArray("results");
                JSONArray blocks = new JSONArray();
                for (int i = 0; i < rs.length(); i++) {
                    JSONObject r = rs.getJSONObject(i);
                    blocks.put(new JSONObject().put("type", "tool_result").put("tool_use_id", r.getString("id"))
                            .put("content", r.getString("content")));
                }
                msgs.put(new JSONObject().put("role", "user").put("content", blocks));
            }
        }
        JSONArray tools = new JSONArray();
        for (int i = 0; i < toolDefs.length(); i++) {
            JSONObject t = toolDefs.getJSONObject(i);
            tools.put(new JSONObject().put("name", t.getString("name"))
                    .put("description", t.getString("description"))
                    .put("input_schema", t.getJSONObject("parameters")));
        }
        JSONObject body = new JSONObject().put("model", cfg.model).put("max_tokens", 2048)
                .put("system", systemPrompt(cfg)).put("messages", msgs).put("tools", tools);
        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-api-key", cfg.key);
        h.put("anthropic-version", "2023-06-01");
        JSONObject data = post(base(cfg) + "/v1/messages", body, h);

        StringBuilder text = new StringBuilder();
        JSONArray calls = new JSONArray();
        JSONArray content = data.optJSONArray("content");
        if (content != null) for (int i = 0; i < content.length(); i++) {
            JSONObject b = content.getJSONObject(i);
            String type = b.optString("type");
            if (type.equals("text")) text.append(b.optString("text"));
            else if (type.equals("tool_use")) {
                JSONObject in = b.optJSONObject("input");
                calls.put(new JSONObject().put("id", b.getString("id")).put("name", b.getString("name"))
                        .put("args", in == null ? new JSONObject() : in));
            }
        }
        return new JSONObject().put("text", text.toString()).put("calls", calls);
    }

    // ------------------------------------------------------------------ Google Gemini
    JSONObject callGemini(Config cfg) throws Exception {
        JSONArray contents = new JSONArray();
        for (JSONObject m : history) {
            String role = m.getString("role");
            if (role.equals("user")) {
                contents.put(new JSONObject().put("role", "user")
                        .put("parts", new JSONArray().put(new JSONObject().put("text", m.getString("text")))));
            } else if (role.equals("assistant")) {
                JSONArray parts = m.optJSONArray("raw");
                if (parts == null || parts.length() == 0) {
                    parts = new JSONArray();
                    String t = m.optString("text", "");
                    if (!t.isEmpty()) parts.put(new JSONObject().put("text", t));
                    JSONArray calls = m.optJSONArray("calls");
                    if (calls != null) for (int i = 0; i < calls.length(); i++) {
                        JSONObject c = calls.getJSONObject(i);
                        parts.put(new JSONObject().put("functionCall", new JSONObject()
                                .put("name", c.getString("name")).put("args", c.getJSONObject("args"))));
                    }
                }
                if (parts.length() > 0) contents.put(new JSONObject().put("role", "model").put("parts", parts));
            } else if (role.equals("tool")) {
                JSONArray rs = m.getJSONArray("results");
                JSONArray parts = new JSONArray();
                for (int i = 0; i < rs.length(); i++) {
                    JSONObject r = rs.getJSONObject(i);
                    parts.put(new JSONObject().put("functionResponse", new JSONObject()
                            .put("name", r.getString("name"))
                            .put("response", new JSONObject().put("result", r.getString("content")))));
                }
                contents.put(new JSONObject().put("role", "user").put("parts", parts));
            }
        }
        JSONArray decls = new JSONArray();
        for (int i = 0; i < toolDefs.length(); i++) {
            JSONObject t = toolDefs.getJSONObject(i);
            JSONObject d = new JSONObject().put("name", t.getString("name")).put("description", t.getString("description"));
            JSONObject params = t.getJSONObject("parameters");
            if (params.getJSONObject("properties").length() > 0) d.put("parameters", params);
            decls.put(d);
        }
        JSONObject body = new JSONObject()
                .put("systemInstruction", new JSONObject().put("parts",
                        new JSONArray().put(new JSONObject().put("text", systemPrompt(cfg)))))
                .put("contents", contents)
                .put("tools", new JSONArray().put(new JSONObject().put("functionDeclarations", decls)));
        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-goog-api-key", cfg.key);
        JSONObject data = post(base(cfg) + "/models/" + cfg.model + ":generateContent", body, h);

        JSONArray parts = new JSONArray();
        JSONArray cands = data.optJSONArray("candidates");
        if (cands != null && cands.length() > 0) {
            JSONObject content = cands.getJSONObject(0).optJSONObject("content");
            if (content != null && content.optJSONArray("parts") != null) parts = content.getJSONArray("parts");
        }
        StringBuilder text = new StringBuilder();
        JSONArray calls = new JSONArray();
        for (int i = 0; i < parts.length(); i++) {
            JSONObject p = parts.getJSONObject(i);
            if (p.has("functionCall")) {
                JSONObject fc = p.getJSONObject("functionCall");
                JSONObject args = fc.optJSONObject("args");
                calls.put(new JSONObject().put("id", newId()).put("name", fc.getString("name"))
                        .put("args", args == null ? new JSONObject() : args));
            } else if (p.has("text") && !p.optBoolean("thought", false)) {
                text.append(p.optString("text"));
            }
        }
        if (parts.length() == 0) text.append("(ИИ вернул пустой ответ)");
        return new JSONObject().put("text", text.toString()).put("calls", calls).put("raw", parts);
    }
}
